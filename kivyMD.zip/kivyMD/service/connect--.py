import logging
import pymssql

class ConnectionForDb:
    def __init__(self):
        try:
            self.connect = pymssql.connect(
                server='127.0.0.1',
                user='ci24',
                password='jupiter2040',
                database='CI_ControlAccessDb'
            )
            logging.info("DATABASE: Successful connection to database")
        except Exception as error:
            logging.error(f"DATABASE: Error connecting to database: {error}")

    def login(self, nm, ps):
        try:
            with self.connect.cursor(as_dict=True) as cur:
                SQL = "SELECT Email, StoredPassword FROM Tb_Users WHERE Email = %s AND StoredPassword = %s"
                cur.execute(SQL, (nm, ps))
                res = cur.fetchone()
                return res
        except Exception as error:
            logging.error(f"CONSULTA: Error al general la consulta : {error}")
            return None

    def close_connect(self):
        logging.info("DATABASE: Offline database")
        self.connect.close()

    def authenticate_user(self, nm, ps):
        try:
            result = self.login(nm, ps)
            self.close_connect()
            return result
        except Exception as error:
            logging.error(f"DATABASE: Error authenticating user: {error}")
            return None
