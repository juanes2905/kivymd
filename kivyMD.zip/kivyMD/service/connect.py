import logging
import os
import pymssql
import json

class ConnectionForDb:
    def __init__(self):
        try:
            config_file_path = r'C:\Gobernador\ServiceJuan\Connect\config.json'
            logging.info(f"DATABASE: Loading config file: {config_file_path}")

            if not os.path.exists(config_file_path):
                #CONFIGURACIÓN CREACCION POR DEFECTO DEL .JSON SI NO LO AHI
                default_config = {
                    "server": "127.0.0.1",
                    "user": "user",
                    "password": "User123",
                    "database": "jupiter_db"
                }
                with open(config_file_path, 'w') as file:
                    json.dump(default_config, file, indent=4)
                    logging.info("DATABASE: Created config file with default configuration")

            with open(config_file_path, 'r') as file:
                config = json.load(file)
                logging.info(f"DATABASE: JSON structure: {config}")

            self.connect = pymssql.connect(
                server=config['server'],
                user=config['user'],
                password=config['password'],
                database=config['database']
            )
            logging.info("DATABASE: Successful connection to database")
        except Exception as error:
            logging.error(f"DATABASE: Error connecting to database: {error}")

    def authenticate_user(self, email, password):
        try:
            cursor = self.connect.cursor()
            query = "SELECT Email, StoredPassword FROM Tb_Users WHERE Email = %s AND StoredPassword = %s"
            cursor.execute(query, (email, password))
            result = cursor.fetchone()
            cursor.close()
            if result:
                return True
            else:
                return False
        except Exception as error:
            logging.error(f"DATABASE: Error executing query: {error}")
            return False

    def close_connect(self):
        try:
            self.connect.close()
            logging.info("DATABASE: Connection closed")
        except Exception as error:
            logging.error(f"DATABASE: Error closing connection: {error}")