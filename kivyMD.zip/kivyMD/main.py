import logging
from kivy.lang import Builder
from kivy.uix.screenmanager import ScreenManager
from kivymd.app import MDApp
from kivymd.uix.bottomsheet import MDGridBottomSheet
from kivymd.uix.card import MDCardSwipe
from kivymd.uix.dialog import MDDialog
from kivymd.uix.relativelayout import MDRelativeLayout
from kivymd.uix.button import MDFlatButton
from kivymd.toast import toast
from kivy.properties import StringProperty
from kivy.uix.textinput import TextInput
from service.connect import ConnectionForDb

class ClickableTextFieldRound(MDRelativeLayout):
    text = StringProperty()
    hint_text = StringProperty()

class SwipeToDeleteItem(MDCardSwipe):
    text = StringProperty()

class Tarea(MDApp):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.dialog = None
        self.service = ConnectionForDb()
        self.name_input = None
        self.password_input = None

    def build(self, **kwargs):
        self.theme_cls.theme_style = "Light"
        self.theme_cls.primary_palette = "Orange"
        
        self.screen_manager = ScreenManager()
        self.Login = Builder.load_file("kv/Login.kv")
        self.screen_manager.add_widget(self.Login)
        self.newStyle = Builder.load_file("kv/newstyle.kv")
        self.screen_manager.add_widget(self.newStyle)
        self.desplegar = Builder.load_file("kv/desplegar.kv")
        self.screen_manager.add_widget(self.desplegar)

        self.principal = Builder.load_file("kv/principal.kv")
        self.principal.ids.contenedor.add_widget(self.screen_manager)

        # Asignar referencias a los campos de entrada
        self.name_input = self.Login.ids.validaInp
        self.password_input = self.Login.ids.clickable.ids.inpPass

        return self.principal

    def on_start(self):
        self.newStyle.ids.md_list.add_widget(SwipeToDeleteItem(text="Reloj"))
        self.newStyle.ids.md_list.add_widget(SwipeToDeleteItem(text="Preba"))
        self.newStyle.ids.md_list.add_widget(SwipeToDeleteItem(text="Preba"))

    def remove_item(self, instance):
        self.newStyle.ids.md_list.remove_widget(instance)

    def listaView(self, item_text):
        if item_text == "Reloj":
            self.screen_manager.current = "desplegable"

    def callback_for_menu_items(self, *args):
        toast(args[0])

    def show_example_grid_bottom_sheet(self):
        bottom_sheet_menu = MDGridBottomSheet()
        data = {
            "Facebook": "facebook",
            "YouTube": "youtube",
            "Twitter": "twitter",
            "Messenger": "facebook-messenger",
            "Camera": "camera",
        }
        for item in data.items():
            bottom_sheet_menu.add_item(
                item[0],
                lambda x, y=item[0]: self.callback_for_menu_items(y),
                icon_src=item[1],
            )
        bottom_sheet_menu.elevation = 0
        bottom_sheet_menu.open()

    def logout(self, instance):
        if self.dialog:
            self.screen_manager.current = "login"
            self.service.close_connect() 
            self.dialog.dismiss()
            # Restablecer los valores de los campos de texto
            if self.name_input:
                self.name_input.text = ""
            if self.password_input:
                self.password_input.text = ""

    def confirm_logout(self):
        if not self.dialog:
            self.dialog = MDDialog(
                text="¿Está seguro de que desea cerrar sesión?",
                elevation=0,
                buttons=[
                    MDFlatButton(
                        text="Cancelar",
                        on_release=self.closeDialog
                    ),
                    MDFlatButton(
                        text="Aceptar",
                        on_release=self.logout
                    ),
                ],
            )
        self.dialog.open()

    def closeDialog(self, *args):
        if self.dialog:
            self.dialog.dismiss()

    def salir(self):
        match self.screen_manager.current:
            case "newview":
                if self.screen_manager.current == "newview":
                    self.screen_manager.current = "login"
                    logging.info("Cargando pantalla de inicio...")
                else:
                    self.screen_manager.current = "login"
                    logging.error("VIEW: Es imposible realizar esta acción")
            case "new":
                if self.screen_manager.current == "new":
                    self.screen_manager.current = "newview"
                    logging.info("VIEW: Esta retrocediendo de la vista new")

    def valUsers(self, service, nm, ps):
        name_inp = self.Login.ids.validaInp
        nm = name_inp.text
        pass_inp = self.Login.ids.clickable.ids.inpPass
        ps = pass_inp.text

        if nm and ps:
            try:
                res = service.authenticate_user(nm, ps) 
                if res:
                    logging.info(f"DATA: Usuario: {nm}")
                    logging.info(f"DATA: Contraseña: {ps}")
                    logging.info("---------------------------------------------------------------")
                    return True
                else:
                    pass_inp.error: True
                    pass_inp.helper_text = "Usuario o contraseña incorrectos"
                    logging.info("---------------------------------------------------------------")
                    logging.error("ACCOUNT: La contraseña es incorrecta ")
                    logging.info("---------------------------------------------------------------")
                    name_inp.error: True
                    name_inp.helper_text = "Usuario o contraseña incorrectos"
                    logging.info("---------------------------------------------------------------")
                    logging.error("ACCOUNT: El usuario es incorrecta ")
                    logging.info("---------------------------------------------------------------")
                    return False
            except Exception as error:
                logging.error(f"DATABASE: Error a realizar la consulta a la base de datos: {error}")
                return False
        else:
            pass_inp.error = True
            pass_inp.helper_text = "Contraseña Incorrecto"
            name_inp.error = True
            name_inp.helper_text = "Nombre de la persona requerido"
            logging.info("---------------------------------------------------------------")
            logging.error("ACCOUNT: Diligencia bien los campos para poder ingresar")
            logging.info("---------------------------------------------------------------")
            return False

    def on_stop(self):
        self.service.closeConnect()

    def ingresar(self):
        name_inp = self.Login.ids.validaInp
        nm = name_inp.text
        pass_inp = self.Login.ids.clickable.ids.inpPass
        ps = pass_inp.text
        service = ConnectionForDb()
        if self.valUsers(service, nm, ps):
            if self.screen_manager.current == "login":
                self.screen_manager.current = "newview"
                logging.info("VIEW: Ingresando a la vista")
                logging.info("-----------------------------------------------------")
            else:
                logging.error("JUAN DICE: Esta intentando realizar una acción invalida")


if __name__ == "__main__":
    Tarea().run()
